import { Strategy } from '../strategy-coordinator'
import { Action } from '../GameInterface'
import { randomNeighbor } from '../utils'
import { kill } from 'process'

const killSelf: Strategy = (units, team, state) => {
    //with probability 1/4, attack your own square 
    let actions : Action [] = []
    for (let unit of units) {
        if (Math.random() < 0.50) {
            actions.push({
                type: 'UNIT',
                action: 'ATTACK',
                target: unit.position,
                unitId: unit.id
            })
        }
    }
    return actions
}

export default killSelf